import { supabase } from '../../lib/supabaseClient';

export default async function handler(req, res) {
  if (req.method === 'GET') {
    const { data, error } = await supabase.from('groups').select('*').order('order_index');
    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json(data);
  }

  if (req.method === 'POST') {
    const { name } = req.body || {};
    if (!name) return res.status(400).json({ error: 'الاسم مطلوب' });

    const { data: existing } = await supabase
      .from('groups')
      .select('order_index')
      .order('order_index', { ascending: false })
      .limit(1);
    const nextOrder = existing && existing.length ? existing[0].order_index + 1 : 0;

    const { data, error } = await supabase
      .from('groups')
      .insert({ name, order_index: nextOrder })
      .select()
      .maybeSingle();
    if (error) return res.status(500).json({ error: error.message });
    return res.status(201).json(data);
  }

  if (req.method === 'DELETE') {
    const { id } = req.query;
    const { error } = await supabase.from('groups').delete().eq('id', id);
    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json({ ok: true });
  }

  res.status(405).end();
}

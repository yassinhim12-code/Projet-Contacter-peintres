import { supabase } from '../../lib/supabaseClient';

export default async function handler(req, res) {
  if (req.method === 'GET') {
    const { data, error } = await supabase
      .from('settings')
      .select('*')
      .eq('key', 'google_sheet_csv_url')
      .maybeSingle();
    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json({ sheet_url: data?.value || '' });
  }

  if (req.method === 'POST') {
    const { sheet_url } = req.body || {};
    const { error } = await supabase
      .from('settings')
      .upsert({ key: 'google_sheet_csv_url', value: sheet_url || '' });
    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json({ ok: true });
  }

  res.status(405).end();
}
